package com.blacklauncher.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.blacklauncher.app.LauncherViewModel
import com.blacklauncher.app.Prep
import com.blacklauncher.app.data.Catalog
import kotlinx.coroutines.launch

enum class Screen(val title: String, val icon: ImageVector) {
    HOME("Главная", Icons.Filled.Home),
    COSMETICS("Косметика", Icons.Filled.Checkroom),
    PROFILE("Профиль", Icons.Filled.Person),
    FRIENDS("Друзья", Icons.Filled.People),
    CHAT("Чат", Icons.Filled.Chat),
    SHOP("Магазин", Icons.Filled.ShoppingCart),
    SETTINGS("Настройки", Icons.Filled.Settings),
    ABOUT("О лаунчере", Icons.Filled.Info)
}

private val bottomTabs = listOf(Screen.HOME, Screen.COSMETICS, Screen.FRIENDS, Screen.CHAT, Screen.SHOP)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LauncherApp(vm: LauncherViewModel) {
    if (!vm.loggedIn) {
        LoginScreen(vm)
        return
    }

    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val imeVisible = WindowInsets.ime.getBottom(LocalDensity.current) > 0

    BackHandler(enabled = drawer.isOpen || screen != Screen.HOME) {
        if (drawer.isOpen) scope.launch { drawer.close() } else screen = Screen.HOME
    }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = C.Bg) {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                        HeadView(Catalog.skin(vm.skinId), Modifier.size(48.dp))
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(vm.nickname, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                StatusDot(true)
                                Spacer(Modifier.width(6.dp))
                                Text("Онлайн", color = C.Green, fontSize = 13.sp)
                            }
                        }
                    }
                    Screen.values().forEach { s ->
                        NavigationDrawerItem(
                            label = { Text(s.title) },
                            icon = { Icon(s.icon, null) },
                            selected = s == screen,
                            onClick = {
                                screen = s
                                scope.launch { drawer.close() }
                            },
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
                            colors = NavigationDrawerItemDefaults.colors(
                                selectedContainerColor = C.Surface2,
                                unselectedContainerColor = Color.Transparent,
                                selectedTextColor = Color.White,
                                selectedIconColor = Color.White,
                                unselectedTextColor = C.Muted,
                                unselectedIconColor = C.Muted
                            )
                        )
                    }
                }
            }
        }
    ) {
        Scaffold(
            containerColor = C.Bg,
            topBar = {
                TopAppBar(
                    title = { Text(screen.title, fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawer.open() } }) {
                            Icon(Icons.Filled.Menu, "Меню")
                        }
                    },
                    actions = {
                        CurrencyChip(vm.gems, gem = true)
                        CurrencyChip(vm.coins, gem = false)
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = C.Bg,
                        titleContentColor = Color.White,
                        navigationIconContentColor = Color.White
                    )
                )
            },
            bottomBar = {
                if (!imeVisible) {
                    NavigationBar(containerColor = C.Surface) {
                        bottomTabs.forEach { s ->
                            NavigationBarItem(
                                selected = screen == s,
                                onClick = { screen = s },
                                icon = { Icon(s.icon, null) },
                                label = { Text(s.title, fontSize = 10.sp, maxLines = 1) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.Black,
                                    selectedTextColor = Color.White,
                                    indicatorColor = Color.White,
                                    unselectedIconColor = C.Muted,
                                    unselectedTextColor = C.Muted
                                )
                            )
                        }
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (screen) {
                    Screen.HOME -> HomeScreen(vm) { screen = it }
                    Screen.COSMETICS -> CosmeticsScreen(vm)
                    Screen.PROFILE -> ProfileScreen(vm)
                    Screen.FRIENDS -> FriendsScreen(vm) { f -> vm.chatWith = f.id; screen = Screen.CHAT }
                    Screen.CHAT -> ChatScreen(vm)
                    Screen.SHOP -> ShopScreen(vm)
                    Screen.SETTINGS -> SettingsScreen(vm)
                    Screen.ABOUT -> AboutScreen()
                }
            }
        }
    }

    HandoffDialog(vm)
}

/** После подготовки версии предлагает открыть установленный игровой клиент. */
@Composable
private fun HandoffDialog(vm: LauncherViewModel) {
    if (vm.prep !is Prep.Done) return
    val ctx = LocalContext.current
    val pm = ctx.packageManager
    val targets = listOf(
        "PojavLauncher" to "net.kdt.pojavlaunch",
        "MojoLauncher" to "git.artdeell.mojo",
        "Minecraft Bedrock" to "com.mojang.minecraftpe"
    ).filter { pm.getLaunchIntentForPackage(it.second) != null }

    AlertDialog(
        onDismissRequest = { vm.prep = Prep.Idle },
        containerColor = C.Surface,
        title = { Text("Версия ${vm.selectedVersionId} готова") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "Файлы версии скачаны с серверов Mojang и проверены (SHA-1). " +
                        "Для запуска Java Edition на Android нужна среда Java и трансляция OpenGL — " +
                        "их даёт PojavLauncher.",
                    fontSize = 14.sp
                )
                if (targets.isEmpty()) {
                    Text(
                        "Ни PojavLauncher, ни Minecraft не найдены на устройстве. " +
                            "Установите PojavLauncher (F-Droid / GitHub) и выберите там эту же версию.",
                        fontSize = 13.sp, color = C.Muted
                    )
                }
                targets.forEach { t ->
                    Button(
                        onClick = {
                            pm.getLaunchIntentForPackage(t.second)?.let { ctx.startActivity(it) }
                            vm.prep = Prep.Idle
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Открыть ${t.first}") }
                }
            }
        },
        confirmButton = { TextButton(onClick = { vm.prep = Prep.Idle }) { Text("Закрыть") } }
    )
}
