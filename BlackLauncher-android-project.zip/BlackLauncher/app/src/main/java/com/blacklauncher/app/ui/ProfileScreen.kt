package com.blacklauncher.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.blacklauncher.app.LauncherViewModel
import com.blacklauncher.app.data.Mojang

@Composable
fun ProfileScreen(vm: LauncherViewModel) {
    var editing by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Panel {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                // Голова скина берётся из бесплатного сервиса mc-heads.net
                AsyncImage(
                    model = "https://mc-heads.net/avatar/${vm.nickname}/128",
                    contentDescription = null,
                    filterQuality = FilterQuality.None,
                    modifier = Modifier.size(88.dp).clip(RoundedCornerShape(14.dp))
                )
                Spacer(Modifier.width(16.dp))
                Column {
                    Text(vm.nickname, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        StatusDot(true)
                        Spacer(Modifier.width(6.dp))
                        Text("Онлайн", color = C.Green, fontSize = 13.sp)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text("UUID: ${vm.uuid}", fontSize = 10.sp, color = C.Muted)
                }
            }
        }

        Panel {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Статистика", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                StatRow("Запусков игры", "${vm.launches}")
                StatRow("Предметов косметики", "${vm.ownedIds.size}")
                StatRow("Друзей", "${vm.friends.size}")
                StatRow("Выбранная версия", vm.selectedVersionId.ifBlank { "—" })
            }
        }

        Panel {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { editing = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Изменить ник")
                }
                OutlinedButton(onClick = { vm.checkMojang() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Проверить ник в Mojang")
                }
                if (vm.mojangStatus.isNotEmpty()) {
                    Text(vm.mojangStatus, fontSize = 12.sp, color = C.Muted)
                }
                Button(onClick = { vm.logout() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Выйти из аккаунта")
                }
            }
        }
    }

    if (editing) {
        var value by remember { mutableStateOf(vm.nickname) }
        val valid = Mojang.NAME_RE.matches(value)
        AlertDialog(
            onDismissRequest = { editing = false },
            containerColor = C.Surface,
            title = { Text("Новый ник") },
            text = {
                Column {
                    OutlinedTextField(
                        value = value,
                        onValueChange = { value = it.take(16) },
                        singleLine = true,
                        isError = !valid
                    )
                    if (!valid) Text("3–16 символов: латиница, цифры, _", fontSize = 12.sp, color = C.Red)
                }
            },
            confirmButton = {
                TextButton(enabled = valid, onClick = { vm.changeNick(value); editing = false }) { Text("Сохранить") }
            },
            dismissButton = { TextButton(onClick = { editing = false }) { Text("Отмена") } }
        )
    }
}

@Composable
private fun StatRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth()) {
        Text(label, color = C.Muted, modifier = Modifier.weight(1f))
        Text(value, fontWeight = FontWeight.SemiBold)
    }
}
