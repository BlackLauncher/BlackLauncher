package com.blacklauncher.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.blacklauncher.app.LauncherViewModel
import com.blacklauncher.app.Prep
import com.blacklauncher.app.data.CTab
import com.blacklauncher.app.data.Catalog

fun typeLabel(type: String) = when (type) {
    "release" -> "Релиз"
    "snapshot" -> "Снапшот"
    "old_beta" -> "Бета"
    "old_alpha" -> "Альфа"
    else -> type
}

@Composable
fun HomeScreen(vm: LauncherViewModel, go: (Screen) -> Unit) {
    var picker by remember { mutableStateOf(false) }
    val skin = Catalog.skin(vm.skinId)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // ---------- герой ----------
        val heroShape = RoundedCornerShape(20.dp)
        Box(
            Modifier.fillMaxWidth().height(340.dp).clip(heroShape)
                .background(Brush.verticalGradient(listOf(Color(0xFF2B2B31), Color(0xFF0E0E10))))
                .border(1.dp, C.Border, heroShape)
        ) {
            PlayerView(
                skin, Catalog.cape(vm.capeId), Catalog.wing(vm.wingsId), Catalog.acc(vm.accId),
                Modifier.fillMaxSize().padding(12.dp)
            )
            Column(Modifier.align(Alignment.TopStart).padding(16.dp)) {
                Text(vm.nickname, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusDot(true)
                    Spacer(Modifier.width(6.dp))
                    Text("Онлайн", color = C.Green, fontSize = 13.sp)
                }
            }
        }

        // ---------- версия + играть ----------
        Panel {
            Column(Modifier.padding(14.dp)) {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { picker = true },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Версия Minecraft", fontSize = 12.sp, color = C.Muted)
                        Text(
                            vm.selectedVersionId.ifBlank { if (vm.loadingVersions) "Загрузка списка…" else "Выбрать версию" },
                            fontSize = 20.sp, fontWeight = FontWeight.Bold
                        )
                    }
                    Icon(Icons.Filled.ArrowDropDown, null, tint = C.Muted)
                }
                Spacer(Modifier.height(12.dp))

                when (val p = vm.prep) {
                    is Prep.Working -> {
                        LinearProgressIndicator(
                            progress = { p.progress },
                            modifier = Modifier.fillMaxWidth(),
                            color = Color.White,
                            trackColor = C.Border
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(p.text, fontSize = 12.sp, color = C.Muted)
                        Spacer(Modifier.height(10.dp))
                    }
                    is Prep.Error -> {
                        Text(p.message, fontSize = 13.sp, color = C.Red)
                        Spacer(Modifier.height(10.dp))
                    }
                    else -> {}
                }

                Button(
                    onClick = { vm.play() },
                    enabled = vm.prep !is Prep.Working,
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Filled.PlayArrow, null)
                    Spacer(Modifier.width(8.dp))
                    Text("ИГРАТЬ", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // ---------- ежедневный бонус ----------
        if (vm.canClaimDaily) {
            Panel {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Ежедневный бонус", fontWeight = FontWeight.SemiBold)
                        Text("+50 монет и +1 кристалл", fontSize = 12.sp, color = C.Muted)
                    }
                    Button(onClick = { vm.claimDaily() }) { Text("Забрать") }
                }
            }
        }

        // ---------- косметика ----------
        Panel {
            SectionHeader("Косметика", Icons.Filled.Checkroom) { go(Screen.COSMETICS) }
            LazyRow(
                contentPadding = PaddingValues(start = 14.dp, end = 14.dp, bottom = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(Catalog.skins, key = { it.id }) { s ->
                    val eq = s.id == vm.skinId
                    val shape = RoundedCornerShape(12.dp)
                    Box(
                        Modifier.width(78.dp).height(100.dp).clip(shape).background(C.Surface2)
                            .border(if (eq) 2.dp else 1.dp, if (eq) Color.White else C.Border, shape)
                            .clickable {
                                if (vm.isOwned(s.id)) vm.equip(CTab.SKINS, s.id) else go(Screen.COSMETICS)
                            }
                            .padding(6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        PlayerView(s, null, null, null, Modifier.fillMaxSize())
                        if (!vm.isOwned(s.id)) {
                            Icon(
                                Icons.Filled.Lock, null, tint = C.Muted,
                                modifier = Modifier.align(Alignment.TopEnd).size(14.dp)
                            )
                        }
                    }
                }
            }
        }

        // ---------- друзья и чат ----------
        Panel {
            SectionHeader("Друзья и чат", Icons.Filled.People) { go(Screen.CHAT) }
            if (vm.friends.isEmpty()) {
                Text("Друзей пока нет", color = C.Muted, modifier = Modifier.padding(14.dp))
            }
            vm.friends.take(3).forEach { f ->
                Row(
                    Modifier.fillMaxWidth().clickable { vm.chatWith = f.id; go(Screen.CHAT) }
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LetterAvatar(f.name)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(f.name, fontWeight = FontWeight.SemiBold)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            StatusDot(f.online)
                            Spacer(Modifier.width(6.dp))
                            Text(if (f.online) "В сети" else "Не в сети", fontSize = 12.sp, color = C.Muted)
                        }
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
        }

        // ---------- магазин ----------
        Panel {
            SectionHeader("Магазин", Icons.Filled.ShoppingCart) { go(Screen.SHOP) }
            Column(Modifier.padding(start = 14.dp, end = 14.dp, bottom = 14.dp)) {
                Text("Покупай косметику и стань уникальным!", fontSize = 15.sp)
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = { go(Screen.SHOP) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.ShoppingCart, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Открыть магазин")
                }
            }
        }
    }

    if (picker) VersionPicker(vm) { picker = false }
}

@Composable
fun VersionPicker(vm: LauncherViewModel, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = C.Surface,
        confirmButton = { TextButton(onClick = onClose) { Text("Готово") } },
        title = { Text("Версия Minecraft") },
        text = {
            Column {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = vm.showSnapshots,
                        onClick = { vm.showSnapshots = !vm.showSnapshots; vm.save() },
                        label = { Text("Снапшоты") }
                    )
                    FilterChip(
                        selected = vm.showOld,
                        onClick = { vm.showOld = !vm.showOld; vm.save() },
                        label = { Text("Старые") }
                    )
                }
                Spacer(Modifier.height(8.dp))
                val list = vm.visibleVersions
                if (list.isEmpty()) {
                    Text(
                        if (vm.loadingVersions) "Загрузка списка…" else (vm.versionsError ?: "Список пуст"),
                        color = C.Muted
                    )
                    TextButton(onClick = { vm.loadVersions() }) { Text("Обновить") }
                }
                LazyColumn(Modifier.heightIn(max = 340.dp)) {
                    items(list, key = { it.id }) { v ->
                        Row(
                            Modifier.fillMaxWidth()
                                .clickable { vm.selectVersion(v.id); onClose() }
                                .padding(vertical = 10.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(v.id, fontWeight = FontWeight.SemiBold)
                                Text(typeLabel(v.type), fontSize = 12.sp, color = C.Muted)
                            }
                            if (v.id == vm.selectedVersionId) Icon(Icons.Filled.Check, null)
                        }
                    }
                }
            }
        }
    )
}
