package com.blacklauncher.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.blacklauncher.app.LauncherViewModel
import com.blacklauncher.app.data.Catalog
import com.blacklauncher.app.data.Currency
import com.blacklauncher.app.data.Item

@Composable
fun ShopScreen(vm: LauncherViewModel) {
    var msg by remember { mutableStateOf("") }
    val goods = Catalog.all()
        .filter { !vm.isOwned(it.id) }
        .sortedWith(compareBy<Item>({ it.currency == Currency.GEMS }, { it.price }))
    val base = Catalog.skin(vm.skinId)

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Panel {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Баланс", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        CurrencyChip(vm.gems, gem = true)
                        CurrencyChip(vm.coins, gem = false)
                    }
                }
                Panel {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Ежедневный бонус", fontWeight = FontWeight.SemiBold)
                            Text("+50 монет и +1 кристалл раз в день", fontSize = 12.sp, color = C.Muted)
                        }
                        Button(onClick = { vm.claimDaily() }, enabled = vm.canClaimDaily) {
                            Text(if (vm.canClaimDaily) "Забрать" else "Завтра")
                        }
                    }
                }
                Panel {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Обмен", fontWeight = FontWeight.SemiBold)
                            Text("500 монет → 5 кристаллов", fontSize = 12.sp, color = C.Muted)
                        }
                        OutlinedButton(onClick = {
                            msg = if (vm.exchangeCoinsToGems()) "Обмен выполнен" else "Нужно 500 монет"
                        }) { Text("Обменять") }
                    }
                }
                if (msg.isNotEmpty()) Text(msg, fontSize = 13.sp, color = C.Muted)
            }
        }

        if (goods.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text(
                    "Вы купили всё, что есть в магазине!",
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    textAlign = TextAlign.Center,
                    color = C.Muted
                )
            }
        }

        items(goods, key = { it.id }) { entry ->
            Panel {
                Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    ItemPreview(base, entry, Modifier.fillMaxWidth().height(120.dp))
                    Spacer(Modifier.height(6.dp))
                    Text(entry.name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text(kindOf(entry), fontSize = 11.sp, color = C.Muted)
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = {
                            msg = if (vm.buy(entry)) {
                                "«${entry.name}» куплено и надето"
                            } else {
                                "Не хватает " + (if (entry.currency == Currency.GEMS) "кристаллов" else "монет")
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                    ) { PriceTag(entry) }
                }
            }
        }
    }
}
