package com.blacklauncher.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.blacklauncher.app.LauncherViewModel
import com.blacklauncher.app.data.ChatMsg
import com.blacklauncher.app.data.Friend
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun FriendsScreen(vm: LauncherViewModel, openChat: (Friend) -> Unit) {
    var name by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Panel {
                Column(Modifier.padding(14.dp)) {
                    Text("Добавить друга", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it.take(16); err = "" },
                            singleLine = true,
                            label = { Text("Ник игрока") },
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(Modifier.width(8.dp))
                        FilledIconButton(onClick = {
                            val e = vm.addFriend(name.trim())
                            if (e == null) name = "" else err = e
                        }) { Icon(Icons.Filled.Add, null) }
                    }
                    if (err.isNotEmpty()) Text(err, color = C.Red, fontSize = 12.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Список друзей хранится на этом устройстве. Статус «в сети» у новых друзей " +
                            "появится после подключения сервера (см. README).",
                        fontSize = 12.sp, color = C.Muted
                    )
                }
            }
        }
        items(vm.friends, key = { it.id }) { f ->
            Panel(onClick = { openChat(f) }) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    LetterAvatar(f.name, 44.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(f.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            StatusDot(f.online)
                            Spacer(Modifier.width(6.dp))
                            Text(if (f.online) "В сети" else "Не в сети", fontSize = 12.sp, color = C.Muted)
                        }
                    }
                    IconButton(onClick = { openChat(f) }) { Icon(Icons.Filled.Chat, null) }
                    IconButton(onClick = { vm.removeFriend(f) }) { Icon(Icons.Filled.Delete, null, tint = C.Muted) }
                }
            }
        }
    }
}

@Composable
fun ChatScreen(vm: LauncherViewModel) {
    if (vm.friends.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Добавьте друга во вкладке «Друзья»", color = C.Muted)
        }
        return
    }

    val current = vm.friends.firstOrNull { it.id == vm.chatWith } ?: vm.friends.first()
    val msgs = vm.chats[current.id].orEmpty()
    val listState = rememberLazyListState()
    var text by remember { mutableStateOf("") }

    LaunchedEffect(msgs.size, current.id) {
        if (msgs.isNotEmpty()) listState.scrollToItem(msgs.size - 1)
    }

    Column(Modifier.fillMaxSize().imePadding()) {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(vm.friends, key = { it.id }) { f ->
                FilterChip(
                    selected = f.id == current.id,
                    onClick = { vm.chatWith = f.id },
                    label = { Text(f.name) },
                    leadingIcon = { StatusDot(f.online) }
                )
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(msgs) { m -> Bubble(m) }
        }

        Text(
            "Чат локальный: сообщения хранятся только на этом устройстве",
            fontSize = 11.sp, color = C.Muted,
            modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
        )
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                placeholder = { Text("Написать сообщение…") },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(24.dp),
                maxLines = 3
            )
            Spacer(Modifier.width(8.dp))
            FilledIconButton(onClick = {
                if (text.isNotBlank()) {
                    vm.sendMessage(current.id, text.trim())
                    text = ""
                }
            }) { Icon(Icons.AutoMirrored.Filled.Send, null) }
        }
    }
}

@Composable
private fun Bubble(m: ChatMsg) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (m.me) Arrangement.End else Arrangement.Start
    ) {
        Column(
            Modifier.widthIn(max = 280.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(if (m.me) Color(0xFFEDEDED) else C.Surface2)
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Text(m.text, color = if (m.me) Color.Black else C.Text)
            Text(
                SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(m.ts)),
                fontSize = 10.sp,
                color = if (m.me) Color(0xFF555555) else C.Muted
            )
        }
    }
}
