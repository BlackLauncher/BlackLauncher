package com.blacklauncher.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import com.blacklauncher.app.data.AccKind
import com.blacklauncher.app.data.Accessory
import com.blacklauncher.app.data.Cape
import com.blacklauncher.app.data.Skin
import com.blacklauncher.app.data.Wings

/** Персонаж целиком: крылья, плащ, скин и аксессуар — всё рисуется кодом. */
@Composable
fun PlayerView(
    skin: Skin,
    cape: Cape?,
    wings: Wings?,
    acc: Accessory?,
    modifier: Modifier = Modifier
) {
    Canvas(modifier) { drawPlayer(skin, cape, wings, acc) }
}

/** Только голова (для маленьких аватарок). */
@Composable
fun HeadView(skin: Skin, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val u = size.minDimension / 8f
        fun r(x: Float, y: Float, w: Float, h: Float, c: Color) =
            drawRect(c, Offset(x * u, y * u), Size(w * u, h * u))
        r(0f, 0f, 8f, 8f, skin.face)
        r(0f, 0f, 8f, 3f, skin.hair)
        r(0f, 0f, 1f, 5f, skin.hair)
        r(7f, 0f, 1f, 5f, skin.hair)
        r(1.5f, 4f, 2f, 1.2f, Color.White)
        r(4.5f, 4f, 2f, 1.2f, Color.White)
        r(2.5f, 4f, 1f, 1.2f, Color(0xFF222222))
        r(5.5f, 4f, 1f, 1.2f, Color(0xFF222222))
    }
}

fun DrawScope.drawPlayer(skin: Skin, cape: Cape?, wings: Wings?, acc: Accessory?) {
    // Сетка 30 x 38 «пикселей», персонаж по центру (x = 15)
    val u = minOf(size.width / 30f, size.height / 38f)
    val ox = (size.width - 30f * u) / 2f
    val oy = (size.height - 38f * u) / 2f

    fun r(x: Float, y: Float, w: Float, h: Float, c: Color) {
        drawRect(c, Offset(ox + x * u, oy + (y + 2f) * u), Size(w * u, h * u))
    }

    // --- крылья (за спиной) ---
    if (wings != null) {
        for (s in intArrayOf(-1, 1)) {
            val pivot = Offset(ox + (15f + s * 3.5f) * u, oy + 15f * u)
            for (i in 0 until wings.count) {
                val a = 18f + i * 17f
                val len = wings.length - i * 0.9f
                rotate(degrees = s * a, pivot = pivot) {
                    drawRect(wings.c1, Offset(pivot.x - 1.2f * u, pivot.y - len * u), Size(2.4f * u, len * u))
                    drawRect(wings.c2, Offset(pivot.x - 1.2f * u, pivot.y - len * u), Size(2.4f * u, 2.6f * u))
                }
            }
        }
    }

    // --- плащ ---
    if (cape != null) {
        r(10f, 10.5f, 10f, 15f, cape.c1)
        r(10f, 23.5f, 10f, 1.5f, cape.c2)
    }

    // --- ноги ---
    r(11f, 22f, 4f, 12f, skin.pants)
    r(15f, 22f, 4f, 12f, skin.pants)
    r(14.9f, 22f, 0.2f, 12f, Color(0x33000000))
    r(11f, 32f, 4f, 2f, skin.accent)
    r(15f, 32f, 4f, 2f, skin.accent)

    // --- тело ---
    r(11f, 10f, 8f, 12f, skin.shirt)
    r(14.6f, 10f, 0.8f, 8f, skin.accent)
    r(11f, 19f, 8f, 0.8f, skin.accent)

    // --- руки ---
    r(7f, 10f, 4f, 10f, skin.shirt)
    r(7f, 20f, 4f, 2f, skin.face)
    r(19f, 10f, 4f, 10f, skin.shirt)
    r(19f, 20f, 4f, 2f, skin.face)

    // --- голова ---
    r(11f, 2f, 8f, 8f, skin.face)
    r(11f, 2f, 8f, 3f, skin.hair)
    r(11f, 2f, 1f, 5f, skin.hair)
    r(18f, 2f, 1f, 5f, skin.hair)
    r(12.5f, 5.5f, 2f, 1.2f, Color.White)
    r(15.5f, 5.5f, 2f, 1.2f, Color.White)
    r(13.5f, 5.5f, 1f, 1.2f, Color(0xFF222222))
    r(16.5f, 5.5f, 1f, 1.2f, Color(0xFF222222))
    r(14f, 8f, 2f, 0.7f, Color(0x55000000))

    // --- аксессуар ---
    if (acc != null) {
        val c = acc.color
        when (acc.kind) {
            AccKind.CROWN -> {
                r(11f, 0f, 8f, 2.2f, c)
                r(11f, -1.2f, 1.6f, 1.4f, c)
                r(14.2f, -1.2f, 1.6f, 1.4f, c)
                r(17.4f, -1.2f, 1.6f, 1.4f, c)
            }
            AccKind.HALO -> drawOval(
                color = c,
                topLeft = Offset(ox + 10.5f * u, oy + 0.5f * u),
                size = Size(9f * u, 2.2f * u),
                style = Stroke(width = 0.7f * u)
            )
            AccKind.GLASSES -> {
                r(11f, 5.2f, 8f, 1.8f, c)
                r(10.5f, 5.2f, 0.5f, 0.8f, c)
                r(19f, 5.2f, 0.5f, 0.8f, c)
            }
            AccKind.HORNS -> {
                r(10.5f, 0.5f, 1.5f, 3f, c)
                r(18f, 0.5f, 1.5f, 3f, c)
                r(10f, -0.7f, 1.2f, 1.4f, c)
                r(18.8f, -0.7f, 1.2f, 1.4f, c)
            }
            AccKind.HEADPHONES -> {
                r(11f, 1.5f, 8f, 1f, c)
                r(10f, 4f, 1.5f, 3.5f, c)
                r(18.5f, 4f, 1.5f, 3.5f, c)
            }
            AccKind.CAP -> {
                r(10.5f, 1f, 9f, 3f, c)
                r(9.5f, 4f, 11f, 1f, Color(0xFF111111))
            }
            AccKind.MASK -> {
                r(11f, 6.5f, 8f, 3.5f, c)
                r(14f, 7.8f, 2f, 0.6f, Color(0x33000000))
            }
            AccKind.SCARF -> {
                r(10.5f, 9.5f, 9f, 2f, c)
                r(17f, 11f, 2f, 4f, c)
            }
            AccKind.EYEPATCH -> {
                r(12f, 5.2f, 2.6f, 2f, c)
                r(11f, 5.6f, 8f, 0.5f, c)
            }
            AccKind.BOWTIE -> {
                r(13f, 10f, 1.6f, 1.6f, c)
                r(15.4f, 10f, 1.6f, 1.6f, c)
                r(14.4f, 10.4f, 1.2f, 0.8f, Color.White)
            }
        }
    }
}
