package com.blacklauncher.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.blacklauncher.app.data.Accessory
import com.blacklauncher.app.data.Cape
import com.blacklauncher.app.data.Currency
import com.blacklauncher.app.data.Item
import com.blacklauncher.app.data.Skin
import com.blacklauncher.app.data.Wings

@Composable
fun Panel(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(16.dp)
    var m = modifier.clip(shape).background(C.Surface).border(1.dp, C.Border, shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(m, content = content)
}

@Composable
fun SectionHeader(title: String, icon: ImageVector, onMore: (() -> Unit)? = null) {
    val base = if (onMore != null) Modifier.fillMaxWidth().clickable(onClick = onMore) else Modifier.fillMaxWidth()
    Row(base.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(10.dp))
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        if (onMore != null) Icon(Icons.Filled.ChevronRight, null, tint = C.Muted)
    }
}

@Composable
fun CurrencyChip(value: Int, gem: Boolean) {
    Row(
        Modifier
            .padding(end = 6.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(C.Surface2)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            if (gem) Icons.Filled.Diamond else Icons.Filled.MonetizationOn,
            null,
            tint = if (gem) C.Gem else C.Gold,
            modifier = Modifier.size(18.dp)
        )
        Spacer(Modifier.width(4.dp))
        Text("$value", fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun StatusDot(online: Boolean) {
    Box(Modifier.size(8.dp).clip(CircleShape).background(if (online) C.Green else C.Muted))
}

@Composable
fun LetterAvatar(name: String, size: Dp = 40.dp) {
    Box(
        Modifier.size(size).clip(CircleShape).background(C.Surface2).border(1.dp, C.Border, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(name.take(1).uppercase(), fontWeight = FontWeight.Bold)
    }
}

fun kindOf(item: Item): String = when (item) {
    is Skin -> "Скин"
    is Cape -> "Плащ"
    is Wings -> "Крылья"
    is Accessory -> "Аксессуар"
    else -> ""
}

fun priceLabel(item: Item): String = when (item.currency) {
    Currency.FREE -> "Бесплатно"
    Currency.COINS -> "${item.price} монет"
    Currency.GEMS -> "${item.price} кристаллов"
}

@Composable
fun PriceTag(item: Item) {
    when (item.currency) {
        Currency.FREE -> Text("Бесплатно", fontSize = 11.sp, color = C.Muted)
        else -> Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (item.currency == Currency.GEMS) Icons.Filled.Diamond else Icons.Filled.MonetizationOn,
                null,
                tint = if (item.currency == Currency.GEMS) C.Gem else C.Gold,
                modifier = Modifier.size(13.dp)
            )
            Spacer(Modifier.width(3.dp))
            Text("${item.price}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

/** Превью предмета на текущем скине игрока. */
@Composable
fun ItemPreview(base: Skin, item: Item?, modifier: Modifier = Modifier) {
    when (item) {
        is Skin -> PlayerView(item, null, null, null, modifier)
        is Cape -> PlayerView(base, item, null, null, modifier)
        is Wings -> PlayerView(base, null, item, null, modifier)
        is Accessory -> PlayerView(base, null, null, item, modifier)
        else -> {}
    }
}
