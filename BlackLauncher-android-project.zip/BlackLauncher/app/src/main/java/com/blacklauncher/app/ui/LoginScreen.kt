package com.blacklauncher.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.blacklauncher.app.LauncherViewModel
import com.blacklauncher.app.data.Catalog
import com.blacklauncher.app.data.Mojang

@Composable
fun LoginScreen(vm: LauncherViewModel) {
    var name by remember { mutableStateOf("") }
    val valid = Mojang.NAME_RE.matches(name)

    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1C1C20), C.Bg)))
            .systemBarsPadding()
            .imePadding()
    ) {
        Column(
            Modifier.align(Alignment.Center).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            PlayerView(
                Catalog.skin("s_shadow"), null, Catalog.wing("w_raven"), null,
                Modifier.size(width = 200.dp, height = 240.dp)
            )
            Spacer(Modifier.height(8.dp))
            Text("BLACK LAUNCHER", fontSize = 26.sp, fontWeight = FontWeight.Black)
            Text("Войдите, чтобы продолжить", color = C.Muted)
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(16) },
                singleLine = true,
                label = { Text("Ник игрока") },
                isError = name.isNotEmpty() && !valid,
                supportingText = { Text("3–16 символов: латиница, цифры, _") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { vm.login(name.trim()) },
                enabled = valid && !vm.loginBusy,
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                if (vm.loginBusy) {
                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.Black)
                } else {
                    Text("Войти", fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(
                "Офлайн-режим: вход по нику без пароля. Если такой ник есть в Mojang, " +
                    "подтянется его UUID. Вход через аккаунт Microsoft пока не реализован.",
                fontSize = 12.sp, color = C.Muted, textAlign = TextAlign.Center
            )
        }
    }
}
