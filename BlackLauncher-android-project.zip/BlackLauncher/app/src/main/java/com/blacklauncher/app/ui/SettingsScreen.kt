package com.blacklauncher.app.ui

import android.app.ActivityManager
import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.blacklauncher.app.LauncherViewModel
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(vm: LauncherViewModel) {
    val ctx = LocalContext.current
    val deviceRam = remember {
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        (mi.totalMem / 1_048_576L).toInt()
    }
    var tick by remember { mutableIntStateOf(0) }
    val sizeMb = remember(tick) { vm.downloadedBytes() / 1_048_576L }
    var confirmReset by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Panel {
            Column(Modifier.padding(16.dp)) {
                Text("Игра", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Spacer(Modifier.height(12.dp))
                Text("Оперативная память: ${vm.ramMb} МБ", fontSize = 14.sp)
                Slider(
                    value = vm.ramMb.toFloat(),
                    onValueChange = { vm.ramMb = ((it / 256f).roundToInt() * 256).coerceIn(512, 4096) },
                    onValueChangeFinished = { vm.save() },
                    valueRange = 512f..4096f,
                    steps = 13,
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = Color.White,
                        inactiveTrackColor = C.Border
                    )
                )
                Text(
                    "Всего в устройстве: $deviceRam МБ. Не выделяйте больше половины.",
                    fontSize = 12.sp, color = C.Muted
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = vm.jvmArgs,
                    onValueChange = { vm.jvmArgs = it; vm.save() },
                    label = { Text("Аргументы JVM") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Panel {
            Column(Modifier.padding(16.dp)) {
                Text("Версии", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                SwitchRow("Показывать снапшоты", vm.showSnapshots) { vm.showSnapshots = it; vm.save() }
                SwitchRow("Показывать старые (бета, альфа)", vm.showOld) { vm.showOld = it; vm.save() }
            }
        }

        Panel {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Хранилище", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Text("Загружено файлов игры: $sizeMb МБ", fontSize = 14.sp)
                Text(vm.versionsDir.absolutePath, fontSize = 11.sp, color = C.Muted)
                OutlinedButton(
                    onClick = { vm.clearDownloads(); tick++ },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Удалить загруженные версии") }
                OutlinedButton(
                    onClick = { vm.loadVersions() },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Обновить список версий") }
            }
        }

        Panel {
            Column(Modifier.padding(16.dp)) {
                Text("Данные", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = { confirmReset = true },
                    colors = ButtonDefaults.buttonColors(containerColor = C.Red, contentColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Сбросить всё") }
            }
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            containerColor = C.Surface,
            title = { Text("Сбросить все данные?") },
            text = { Text("Аккаунт, покупки, друзья, чаты, настройки и загруженные файлы будут удалены.") },
            confirmButton = {
                TextButton(onClick = { vm.resetAll(); confirmReset = false }) { Text("Сбросить", color = C.Red) }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Отмена") } }
        )
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black,
                checkedTrackColor = Color.White,
                uncheckedTrackColor = C.Surface2
            )
        )
    }
}

@Composable
fun AboutScreen() {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Panel {
            Column(Modifier.padding(16.dp)) {
                Text("Black Launcher", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Версия 1.0.0", color = C.Muted, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                Text(
                    "Тёмный минималистичный лаунчер для Android с косметикой, магазином, " +
                        "друзьями и чатом. Исходный код открыт, все инструменты бесплатные."
                )
            }
        }
        Panel {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Что работает", fontWeight = FontWeight.SemiBold)
                Text("• Список версий Minecraft с серверов Mojang", fontSize = 14.sp)
                Text("• Загрузка client.jar и проверка SHA-1", fontSize = 14.sp)
                Text("• Вход по нику, проверка ника в Mojang", fontSize = 14.sp)
                Text("• Косметика, магазин, бонусы, профиль, настройки", fontSize = 14.sp)
                Text("• Друзья и чат (локально на устройстве)", fontSize = 14.sp)
            }
        }
        Panel {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Важные ограничения", fontWeight = FontWeight.SemiBold)
                Text(
                    "Запуск Minecraft: Java Edition на Android требует Java и перевода OpenGL — " +
                        "это делает отдельное приложение (например, PojavLauncher). Кнопка «Играть» " +
                        "готовит файлы версии и открывает установленный игровой клиент.",
                    fontSize = 14.sp
                )
                Text(
                    "Косметика видна в лаунчере. В самой игре она не появится без серверной " +
                        "или модовой поддержки.",
                    fontSize = 14.sp
                )
            }
        }
        Text(
            "Не является продуктом Mojang Studios или Microsoft. Minecraft — торговая марка Mojang Synergies AB.",
            fontSize = 11.sp, color = C.Muted
        )
    }
}
