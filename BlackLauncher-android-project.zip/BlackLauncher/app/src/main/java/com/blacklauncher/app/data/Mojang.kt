package com.blacklauncher.app.data

import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.UUID

/** Работа с официальными бесплатными API Mojang. Ключи не нужны. */
object Mojang {

    const val MANIFEST_URL = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
    val NAME_RE = Regex("^[A-Za-z0-9_]{3,16}$")

    private fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000
        c.readTimeout = 30_000
        c.setRequestProperty("User-Agent", "BlackLauncher/1.0")
        return c
    }

    private fun getText(url: String): String {
        val c = open(url)
        if (c.responseCode !in 200..299) throw IOException("Сервер ответил: HTTP ${c.responseCode}")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    fun fetchManifest(): String = getText(MANIFEST_URL)

    /** Возвращает (uuid, ник) лицензионного аккаунта или null. */
    fun lookup(name: String): Pair<String, String>? {
        return try {
            val c = open("https://api.mojang.com/users/profiles/minecraft/$name")
            if (c.responseCode != 200) return null
            val o = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            val raw = o.getString("id")
            val uuid = "${raw.substring(0, 8)}-${raw.substring(8, 12)}-${raw.substring(12, 16)}-" +
                "${raw.substring(16, 20)}-${raw.substring(20)}"
            uuid to o.getString("name")
        } catch (e: Exception) {
            null
        }
    }

    fun offlineUuid(name: String): String =
        UUID.nameUUIDFromBytes("OfflinePlayer:$name".toByteArray(Charsets.UTF_8)).toString()

    private fun sha1Of(f: File): String {
        val md = MessageDigest.getInstance("SHA-1")
        f.inputStream().use { input ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    /**
     * Скачивает описание версии и client.jar с серверов Mojang,
     * проверяет SHA-1. Если файл уже есть и цел — ничего не качает.
     */
    fun prepare(v: McVersion, root: File, onProgress: (Float, String) -> Unit) {
        val dir = File(root, v.id).apply { mkdirs() }
        onProgress(0f, "Загрузка описания версии…")
        val json = getText(v.url)
        File(dir, "${v.id}.json").writeText(json)

        val downloads = JSONObject(json).optJSONObject("downloads")
        val client = downloads?.optJSONObject("client")
            ?: throw IOException("У версии ${v.id} нет клиента для скачивания")
        val url = client.getString("url")
        val sha1 = client.getString("sha1")

        val jar = File(dir, "${v.id}.jar")
        onProgress(0.02f, "Проверка файлов…")
        if (jar.exists() && sha1Of(jar) == sha1) {
            onProgress(1f, "Файлы уже загружены")
            return
        }

        val tmp = File(dir, "${v.id}.jar.part")
        val c = open(url)
        if (c.responseCode !in 200..299) throw IOException("Сервер ответил: HTTP ${c.responseCode}")
        val total = c.contentLengthLong
        c.inputStream.use { input ->
            tmp.outputStream().use { out ->
                val buf = ByteArray(64 * 1024)
                var done = 0L
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    if (total > 0) {
                        onProgress(
                            0.05f + 0.9f * (done.toFloat() / total),
                            "Загрузка client.jar: ${done / 1_048_576} / ${total / 1_048_576} МБ"
                        )
                    }
                }
            }
        }
        onProgress(0.97f, "Проверка SHA-1…")
        if (sha1Of(tmp) != sha1) {
            tmp.delete()
            throw IOException("Контрольная сумма не совпала, попробуйте ещё раз")
        }
        jar.delete()
        tmp.renameTo(jar)
        onProgress(1f, "Готово")
    }
}
