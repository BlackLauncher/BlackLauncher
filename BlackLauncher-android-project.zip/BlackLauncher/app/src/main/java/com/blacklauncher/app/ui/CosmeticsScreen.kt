package com.blacklauncher.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.blacklauncher.app.LauncherViewModel
import com.blacklauncher.app.data.CTab
import com.blacklauncher.app.data.Catalog
import com.blacklauncher.app.data.Currency
import com.blacklauncher.app.data.Item

@Composable
fun CosmeticsScreen(vm: LauncherViewModel) {
    var tab by rememberSaveable { mutableStateOf(CTab.SKINS) }
    var sel by remember(tab) { mutableStateOf(vm.equippedId(tab)) }
    var msg by remember { mutableStateOf("") }

    val options: List<Item?> = when (tab) {
        CTab.SKINS -> Catalog.skins
        CTab.CAPES -> listOf<Item?>(null) + Catalog.capes
        CTab.WINGS -> listOf<Item?>(null) + Catalog.wings
        CTab.ACCS -> listOf<Item?>(null) + Catalog.accs
    }

    val pSkin = Catalog.skin(if (tab == CTab.SKINS) sel else vm.skinId)
    val pCape = Catalog.cape(if (tab == CTab.CAPES) sel else vm.capeId)
    val pWings = Catalog.wing(if (tab == CTab.WINGS) sel else vm.wingsId)
    val pAcc = Catalog.acc(if (tab == CTab.ACCS) sel else vm.accId)

    val item = options.firstOrNull { (it?.id ?: "") == sel }
    val owned = item == null || vm.isOwned(item.id)
    val equipped = sel == vm.equippedId(tab)

    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                TabRow(
                    selectedTabIndex = tab.ordinal,
                    containerColor = C.Surface,
                    contentColor = Color.White,
                    modifier = Modifier.clip(RoundedCornerShape(12.dp))
                ) {
                    CTab.values().forEach { t ->
                        Tab(
                            selected = t == tab,
                            onClick = { tab = t; msg = "" },
                            text = { Text(t.title, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                        )
                    }
                }

                val shape = RoundedCornerShape(20.dp)
                Box(
                    Modifier.fillMaxWidth().height(260.dp).clip(shape)
                        .background(Brush.verticalGradient(listOf(Color(0xFF2B2B31), Color(0xFF0E0E10))))
                        .border(1.dp, C.Border, shape)
                ) {
                    PlayerView(pSkin, pCape, pWings, pAcc, Modifier.fillMaxSize().padding(10.dp))
                    Text(
                        item?.name ?: "Без предмета",
                        modifier = Modifier.align(Alignment.TopStart).padding(14.dp),
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }

                Button(
                    onClick = {
                        if (owned) {
                            vm.equip(tab, sel)
                            msg = ""
                        } else {
                            val it2 = item!!
                            msg = if (vm.buy(it2)) {
                                "Куплено и надето!"
                            } else {
                                "Не хватает " + (if (it2.currency == Currency.GEMS) "кристаллов" else "монет") +
                                    ". Загляните в «Магазин» за бонусом."
                            }
                        }
                    },
                    enabled = !equipped,
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(
                        when {
                            equipped -> "Надето"
                            owned -> "Надеть"
                            else -> "Купить · " + priceLabel(item!!)
                        },
                        fontWeight = FontWeight.Bold
                    )
                }
                if (msg.isNotEmpty()) Text(msg, fontSize = 13.sp, color = C.Muted)
            }
        }

        items(options) { opt ->
            val id = opt?.id ?: ""
            val isSel = id == sel
            val isEq = id == vm.equippedId(tab)
            val isOwned = opt == null || vm.isOwned(opt.id)
            val shape = RoundedCornerShape(12.dp)
            Column(
                Modifier.clip(shape).background(C.Surface)
                    .border(if (isSel) 2.dp else 1.dp, if (isSel) Color.White else C.Border, shape)
                    .clickable { sel = id; msg = "" }
                    .padding(6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(Modifier.fillMaxWidth().height(96.dp), contentAlignment = Alignment.Center) {
                    if (opt == null) {
                        Icon(Icons.Filled.Block, null, tint = C.Muted)
                    } else {
                        ItemPreview(Catalog.skin(vm.skinId), opt, Modifier.fillMaxSize())
                    }
                    if (isEq) {
                        Icon(
                            Icons.Filled.CheckCircle, null, tint = C.Green,
                            modifier = Modifier.align(Alignment.TopEnd).size(18.dp)
                        )
                    } else if (!isOwned) {
                        Icon(
                            Icons.Filled.Lock, null, tint = C.Muted,
                            modifier = Modifier.align(Alignment.TopEnd).size(14.dp)
                        )
                    }
                }
                Text(
                    opt?.name ?: "Нет",
                    fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center
                )
                when {
                    isEq -> Text("Надето", fontSize = 11.sp, color = C.Green)
                    isOwned -> Text("Куплено", fontSize = 11.sp, color = C.Muted)
                    else -> PriceTag(opt!!)
                }
            }
        }
    }
}
