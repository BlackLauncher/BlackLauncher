package com.blacklauncher.app.data

import androidx.compose.ui.graphics.Color

enum class Currency { FREE, COINS, GEMS }

enum class CTab(val title: String) {
    SKINS("Скины"), CAPES("Плащи"), WINGS("Крылья"), ACCS("Аксессуары")
}

interface Item {
    val id: String
    val name: String
    val price: Int
    val currency: Currency
}

data class Skin(
    override val id: String,
    override val name: String,
    val hair: Color,
    val face: Color,
    val shirt: Color,
    val pants: Color,
    val accent: Color,
    override val price: Int = 0,
    override val currency: Currency = Currency.FREE
) : Item

data class Cape(
    override val id: String,
    override val name: String,
    val c1: Color,
    val c2: Color,
    override val price: Int = 0,
    override val currency: Currency = Currency.FREE
) : Item

data class Wings(
    override val id: String,
    override val name: String,
    val c1: Color,
    val c2: Color,
    val count: Int,
    val length: Float,
    override val price: Int = 0,
    override val currency: Currency = Currency.FREE
) : Item

enum class AccKind { CROWN, HALO, GLASSES, HORNS, HEADPHONES, CAP, MASK, SCARF, EYEPATCH, BOWTIE }

data class Accessory(
    override val id: String,
    override val name: String,
    val kind: AccKind,
    val color: Color,
    override val price: Int = 0,
    override val currency: Currency = Currency.FREE
) : Item

data class Friend(val id: String, val name: String, val online: Boolean, val demo: Boolean = false)

data class ChatMsg(val me: Boolean, val text: String, val ts: Long)

data class McVersion(val id: String, val type: String, val url: String, val releaseTime: String)
