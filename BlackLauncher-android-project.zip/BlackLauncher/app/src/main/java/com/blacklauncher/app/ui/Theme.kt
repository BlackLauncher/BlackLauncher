package com.blacklauncher.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object C {
    val Bg = Color(0xFF0B0B0D)
    val Surface = Color(0xFF141417)
    val Surface2 = Color(0xFF1C1C20)
    val Border = Color(0xFF2A2A30)
    val Text = Color(0xFFEDEDED)
    val Muted = Color(0xFF8A8A93)
    val Gem = Color(0xFFA259FF)
    val Gold = Color(0xFFFFC233)
    val Green = Color(0xFF3DDC84)
    val Red = Color(0xFFFF5252)
}

@Composable
fun LauncherTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFFF2F2F2),
            onPrimary = Color(0xFF0B0B0D),
            secondary = C.Gem,
            background = C.Bg,
            onBackground = C.Text,
            surface = C.Surface,
            onSurface = C.Text,
            surfaceVariant = C.Surface2,
            onSurfaceVariant = C.Muted,
            outline = C.Border,
            error = C.Red
        ),
        content = content
    )
}
