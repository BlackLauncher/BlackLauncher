package com.blacklauncher.app.data

import androidx.compose.ui.graphics.Color

private fun hx(v: Long) = Color(v)

/**
 * Каталог косметики. Все предметы рисуются кодом (см. ui/Avatar.kt),
 * поэтому не нужны ни картинки, ни сервер. Чтобы добавить предмет —
 * просто добавьте строку в нужный список.
 */
object Catalog {

    val skins = listOf(
        Skin("s_shadow", "Тень", hx(0xFF1A1A1F), hx(0xFFD9B99B), hx(0xFF16161A), hx(0xFF0F0F12), hx(0xFFCFCFCF)),
        Skin("s_snow", "Снежок", hx(0xFFF0F0F0), hx(0xFFE8C9A8), hx(0xFFF2F2F2), hx(0xFF2A2A30), hx(0xFF111111)),
        Skin("s_forest", "Охотник", hx(0xFF3E2A14), hx(0xFFD2A679), hx(0xFF2E4A2B), hx(0xFF3B2F1E), hx(0xFF8BC34A), 180, Currency.COINS),
        Skin("s_ember", "Эмбер", hx(0xFF1A1A1F), hx(0xFFD9B99B), hx(0xFF241515), hx(0xFF140D0D), hx(0xFFFF7A1A), 150, Currency.COINS),
        Skin("s_phantom", "Призрак", hx(0xFFF5F5F5), hx(0xFFF0F0F0), hx(0xFFEDEDED), hx(0xFF1A1A1A), hx(0xFF000000), 200, Currency.COINS),
        Skin("s_albino", "Альбинос", hx(0xFFE8E8F0), hx(0xFFF0EAEA), hx(0xFFDADADF), hx(0xFF3A3A46), hx(0xFF9A9AA8), 250, Currency.COINS),
        Skin("s_ninja", "Ниндзя", hx(0xFF111111), hx(0xFF1A1A1A), hx(0xFF222228), hx(0xFF1A1A1E), hx(0xFFB71C1C), 300, Currency.COINS),
        Skin("s_king", "Король", hx(0xFF4A2E12), hx(0xFFC89B72), hx(0xFF1C1C20), hx(0xFF121214), hx(0xFFFFC233), 400, Currency.COINS),
        Skin("s_cyber", "Кибер", hx(0xFF0A2A33), hx(0xFF9ED8E0), hx(0xFF0F1F24), hx(0xFF0A1418), hx(0xFF00E5FF), 20, Currency.GEMS),
        Skin("s_demon", "Демон", hx(0xFF2A0000), hx(0xFFC9A0A0), hx(0xFF1A0A0A), hx(0xFF120707), hx(0xFFFF1744), 25, Currency.GEMS),
        Skin("s_void", "Бездна", hx(0xFF1B0B2E), hx(0xFF8A6FB5), hx(0xFF1A0F2B), hx(0xFF0F0818), hx(0xFFB05CFF), 30, Currency.GEMS),
        Skin("s_gold", "Золотой рыцарь", hx(0xFF3A2A10), hx(0xFFD9B99B), hx(0xFFD4A017), hx(0xFF8A6A0E), hx(0xFFFFF3B0), 40, Currency.GEMS)
    )

    val capes = listOf(
        Cape("c_black", "Чёрный", hx(0xFF111114), hx(0xFF2A2A30)),
        Cape("c_forest", "Лесной", hx(0xFF1B5E20), hx(0xFF66BB6A), 100, Currency.COINS),
        Cape("c_white", "Белый", hx(0xFFEDEDED), hx(0xFFB0B0B8), 80, Currency.COINS),
        Cape("c_crimson", "Багровый", hx(0xFF7F0F1A), hx(0xFFD32F2F), 120, Currency.COINS),
        Cape("c_ocean", "Океан", hx(0xFF0D47A1), hx(0xFF00B0FF), 140, Currency.COINS),
        Cape("c_royal", "Королевский", hx(0xFF4A148C), hx(0xFFFFC233), 15, Currency.GEMS),
        Cape("c_flame", "Пламя", hx(0xFFBF360C), hx(0xFFFFAB00), 18, Currency.GEMS),
        Cape("c_galaxy", "Галактика", hx(0xFF1A0B3B), hx(0xFF7C4DFF), 30, Currency.GEMS)
    )

    val wings = listOf(
        Wings("w_raven", "Ворон", hx(0xFF111114), hx(0xFF3A3A42), 5, 11f),
        Wings("w_bat", "Летучая мышь", hx(0xFF2A2A30), hx(0xFF111114), 3, 9f, 220, Currency.COINS),
        Wings("w_toxic", "Токсик", hx(0xFF2E7D32), hx(0xFF76FF03), 5, 10f, 260, Currency.COINS),
        Wings("w_angel", "Ангел", hx(0xFFF5F5F5), hx(0xFFCFD8DC), 5, 11f, 300, Currency.COINS),
        Wings("w_ender", "Эндер", hx(0xFF1B0B2E), hx(0xFFB05CFF), 5, 11f, 30, Currency.GEMS),
        Wings("w_phoenix", "Феникс", hx(0xFFFF6D00), hx(0xFFFFD600), 5, 12f, 35, Currency.GEMS),
        Wings("w_crystal", "Кристалл", hx(0xFF00B8D4), hx(0xFFE0F7FA), 4, 10f, 40, Currency.GEMS),
        Wings("w_dragon", "Дракон", hx(0xFF4A0000), hx(0xFFFF1744), 4, 12f, 45, Currency.GEMS)
    )

    val accs = listOf(
        Accessory("a_shades", "Очки", AccKind.GLASSES, hx(0xFF111111)),
        Accessory("a_bow", "Бабочка", AccKind.BOWTIE, hx(0xFF8E24AA), 40, Currency.COINS),
        Accessory("a_patch", "Повязка", AccKind.EYEPATCH, hx(0xFF000000), 50, Currency.COINS),
        Accessory("a_scarf", "Шарф", AccKind.SCARF, hx(0xFFC62828), 60, Currency.COINS),
        Accessory("a_cap", "Кепка", AccKind.CAP, hx(0xFF37474F), 70, Currency.COINS),
        Accessory("a_phones", "Наушники", AccKind.HEADPHONES, hx(0xFF2A2A30), 90, Currency.COINS),
        Accessory("a_mask", "Маска", AccKind.MASK, hx(0xFFE0E0E0), 110, Currency.COINS),
        Accessory("a_halo", "Нимб", AccKind.HALO, hx(0xFFFFF176), 120, Currency.COINS),
        Accessory("a_horns", "Рога", AccKind.HORNS, hx(0xFFB71C1C), 150, Currency.COINS),
        Accessory("a_crown", "Корона", AccKind.CROWN, hx(0xFFFFC233), 20, Currency.GEMS)
    )

    fun all(): List<Item> = buildList {
        addAll(skins); addAll(capes); addAll(wings); addAll(accs)
    }

    fun freeIds(): Set<String> = all().filter { it.currency == Currency.FREE }.map { it.id }.toSet()

    fun skin(id: String): Skin = skins.firstOrNull { it.id == id } ?: skins[0]
    fun cape(id: String): Cape? = capes.firstOrNull { it.id == id }
    fun wing(id: String): Wings? = wings.firstOrNull { it.id == id }
    fun acc(id: String): Accessory? = accs.firstOrNull { it.id == id }
}
