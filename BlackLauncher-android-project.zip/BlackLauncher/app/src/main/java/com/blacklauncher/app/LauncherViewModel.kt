package com.blacklauncher.app

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.blacklauncher.app.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.LocalDate

sealed class Prep {
    object Idle : Prep()
    data class Working(val progress: Float, val text: String) : Prep()
    object Done : Prep()
    data class Error(val message: String) : Prep()
}

class LauncherViewModel(app: Application) : AndroidViewModel(app) {

    private val sp = app.getSharedPreferences("launcher", Context.MODE_PRIVATE)
    val versionsDir = File(app.filesDir, "versions").apply { mkdirs() }
    private val manifestCache = File(app.filesDir, "manifest.json")

    // ---------- аккаунт ----------
    var loggedIn by mutableStateOf(sp.getBoolean("logged", false))
        private set
    var nickname by mutableStateOf(sp.getString("nick", "") ?: "")
        private set
    var uuid by mutableStateOf(sp.getString("uuid", "") ?: "")
        private set
    var loginBusy by mutableStateOf(false)
        private set
    var mojangStatus by mutableStateOf("")
        private set

    // ---------- валюта и косметика ----------
    var coins by mutableIntStateOf(sp.getInt("coins", 100))
        private set
    var gems by mutableIntStateOf(sp.getInt("gems", 5))
        private set
    var ownedIds by mutableStateOf(
        sp.getStringSet("owned", null)?.toSet() ?: Catalog.freeIds()
    )
        private set
    var skinId by mutableStateOf(sp.getString("skin", "s_shadow") ?: "s_shadow")
        private set
    var capeId by mutableStateOf(sp.getString("cape", "") ?: "")
        private set
    var wingsId by mutableStateOf(sp.getString("wings", "w_raven") ?: "w_raven")
        private set
    var accId by mutableStateOf(sp.getString("acc", "") ?: "")
        private set
    var lastDaily by mutableStateOf(sp.getString("daily", "") ?: "")
        private set
    var launches by mutableIntStateOf(sp.getInt("launches", 0))
        private set

    // ---------- настройки ----------
    var ramMb by mutableIntStateOf(sp.getInt("ram", 2048))
    var jvmArgs by mutableStateOf(sp.getString("jvm", "-XX:+UseG1GC") ?: "")
    var showSnapshots by mutableStateOf(sp.getBoolean("snap", false))
    var showOld by mutableStateOf(sp.getBoolean("old", false))

    // ---------- версии ----------
    var versions by mutableStateOf<List<McVersion>>(emptyList())
        private set
    var selectedVersionId by mutableStateOf(sp.getString("version", "") ?: "")
        private set
    var loadingVersions by mutableStateOf(false)
        private set
    var versionsError by mutableStateOf<String?>(null)
        private set
    var prep by mutableStateOf<Prep>(Prep.Idle)

    val visibleVersions: List<McVersion>
        get() = versions.filter {
            when (it.type) {
                "release" -> true
                "snapshot" -> showSnapshots
                else -> showOld
            }
        }

    // ---------- друзья и чат ----------
    val friends = mutableStateListOf<Friend>()
    val chats = mutableStateMapOf<String, List<ChatMsg>>()
    var chatWith by mutableStateOf("")

    init {
        loadSocial()
        loadVersions()
    }

    // =====================================================
    //  Сохранение
    // =====================================================
    fun save() = persist()

    private fun persist() {
        sp.edit()
            .putBoolean("logged", loggedIn)
            .putString("nick", nickname)
            .putString("uuid", uuid)
            .putInt("coins", coins)
            .putInt("gems", gems)
            .putStringSet("owned", HashSet(ownedIds))
            .putString("skin", skinId)
            .putString("cape", capeId)
            .putString("wings", wingsId)
            .putString("acc", accId)
            .putString("daily", lastDaily)
            .putInt("launches", launches)
            .putInt("ram", ramMb)
            .putString("jvm", jvmArgs)
            .putBoolean("snap", showSnapshots)
            .putBoolean("old", showOld)
            .putString("version", selectedVersionId)
            .putString("friends", friendsJson())
            .putString("chats", chatsJson())
            .apply()
    }

    private fun friendsJson(): String {
        val arr = JSONArray()
        friends.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("name", it.name)
                    .put("online", it.online).put("demo", it.demo)
            )
        }
        return arr.toString()
    }

    private fun chatsJson(): String {
        val root = JSONObject()
        chats.forEach { (k, list) ->
            val arr = JSONArray()
            list.forEach { arr.put(JSONObject().put("me", it.me).put("text", it.text).put("ts", it.ts)) }
            root.put(k, arr)
        }
        return root.toString()
    }

    private fun loadSocial() {
        val f = sp.getString("friends", null)
        if (f == null) {
            seedDemo()
            return
        }
        try {
            val arr = JSONArray(f)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                friends.add(Friend(o.getString("id"), o.getString("name"), o.optBoolean("online"), o.optBoolean("demo")))
            }
            val c = JSONObject(sp.getString("chats", "{}") ?: "{}")
            c.keys().forEach { k ->
                val a = c.getJSONArray(k)
                chats[k] = (0 until a.length()).map {
                    val o = a.getJSONObject(it)
                    ChatMsg(o.getBoolean("me"), o.getString("text"), o.getLong("ts"))
                }
            }
        } catch (e: Exception) {
            friends.clear(); chats.clear(); seedDemo()
        }
    }

    private fun seedDemo() {
        friends.add(Friend("f1", "BestFriend", true, true))
        friends.add(Friend("f2", "Killer228", false, true))
        friends.add(Friend("f3", "Dimasik", true, true))
        val now = System.currentTimeMillis()
        chats["f1"] = listOf(
            ChatMsg(false, "Привет", now - 120_000),
            ChatMsg(true, "Привет бро!", now - 60_000)
        )
        chatWith = "f1"
        persist()
    }

    // =====================================================
    //  Вход
    // =====================================================
    fun login(name: String) {
        viewModelScope.launch {
            loginBusy = true
            val real = withContext(Dispatchers.IO) { Mojang.lookup(name) }
            nickname = real?.second ?: name
            uuid = real?.first ?: Mojang.offlineUuid(name)
            loggedIn = true
            loginBusy = false
            persist()
        }
    }

    fun changeNick(name: String) {
        nickname = name
        uuid = Mojang.offlineUuid(name)
        mojangStatus = ""
        persist()
    }

    fun logout() {
        loggedIn = false
        persist()
    }

    fun checkMojang() {
        viewModelScope.launch {
            mojangStatus = "Проверка…"
            val r = withContext(Dispatchers.IO) { Mojang.lookup(nickname) }
            mojangStatus = if (r != null) {
                "Лицензионный ник найден. UUID: ${r.first}"
            } else {
                "Такого ника нет в Mojang (или нет сети). Вход работает в офлайн-режиме."
            }
        }
    }

    // =====================================================
    //  Косметика, магазин
    // =====================================================
    fun isOwned(id: String) = ownedIds.contains(id)

    fun equippedId(t: CTab): String = when (t) {
        CTab.SKINS -> skinId
        CTab.CAPES -> capeId
        CTab.WINGS -> wingsId
        CTab.ACCS -> accId
    }

    fun equip(t: CTab, id: String) {
        when (t) {
            CTab.SKINS -> skinId = id
            CTab.CAPES -> capeId = id
            CTab.WINGS -> wingsId = id
            CTab.ACCS -> accId = id
        }
        persist()
    }

    private fun equipItem(item: Item) {
        when (item) {
            is Skin -> skinId = item.id
            is Cape -> capeId = item.id
            is Wings -> wingsId = item.id
            is Accessory -> accId = item.id
        }
    }

    /** Покупка за внутриигровую валюту. true — куплено (или уже было). */
    fun buy(item: Item): Boolean {
        if (isOwned(item.id)) return true
        when (item.currency) {
            Currency.COINS -> {
                if (coins < item.price) return false
                coins -= item.price
            }
            Currency.GEMS -> {
                if (gems < item.price) return false
                gems -= item.price
            }
            Currency.FREE -> {}
        }
        ownedIds = ownedIds + item.id
        equipItem(item)
        persist()
        return true
    }

    val canClaimDaily: Boolean get() = lastDaily != LocalDate.now().toString()

    fun claimDaily() {
        if (!canClaimDaily) return
        coins += 50
        gems += 1
        lastDaily = LocalDate.now().toString()
        persist()
    }

    fun exchangeCoinsToGems(): Boolean {
        if (coins < 500) return false
        coins -= 500
        gems += 5
        persist()
        return true
    }

    // =====================================================
    //  Версии Minecraft и запуск
    // =====================================================
    fun selectVersion(id: String) {
        selectedVersionId = id
        persist()
    }

    fun loadVersions() {
        viewModelScope.launch {
            loadingVersions = true
            versionsError = null
            val text = withContext(Dispatchers.IO) {
                try {
                    val t = Mojang.fetchManifest()
                    manifestCache.writeText(t)
                    t
                } catch (e: Exception) {
                    versionsError = "Нет сети — показан сохранённый список"
                    if (manifestCache.exists()) manifestCache.readText() else null
                }
            }
            if (text != null) {
                try {
                    parseManifest(text)
                } catch (e: Exception) {
                    versionsError = "Не удалось прочитать список версий"
                }
            } else {
                versionsError = "Не удалось загрузить версии. Проверьте интернет."
            }
            loadingVersions = false
        }
    }

    private fun parseManifest(text: String) {
        val root = JSONObject(text)
        val arr = root.getJSONArray("versions")
        versions = (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            McVersion(o.getString("id"), o.getString("type"), o.getString("url"), o.optString("releaseTime"))
        }
        if (selectedVersionId.isBlank()) {
            selectedVersionId = root.getJSONObject("latest").getString("release")
        }
    }

    fun play() {
        if (prep is Prep.Working) return
        val v = versions.firstOrNull { it.id == selectedVersionId }
        if (v == null) {
            prep = Prep.Error("Выберите версию Minecraft (нужен интернет для списка)")
            return
        }
        viewModelScope.launch {
            prep = Prep.Working(0f, "Подготовка…")
            try {
                withContext(Dispatchers.IO) {
                    Mojang.prepare(v, versionsDir) { p, t -> prep = Prep.Working(p, t) }
                }
                launches++
                persist()
                prep = Prep.Done
            } catch (e: Exception) {
                prep = Prep.Error(e.message ?: "Ошибка загрузки")
            }
        }
    }

    fun downloadedBytes(): Long =
        versionsDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }

    fun clearDownloads() {
        versionsDir.deleteRecursively()
        versionsDir.mkdirs()
    }

    // =====================================================
    //  Друзья и чат (локально, без сервера)
    // =====================================================
    /** Возвращает текст ошибки или null, если друг добавлен. */
    fun addFriend(name: String): String? {
        if (!Mojang.NAME_RE.matches(name)) return "Ник: 3–16 символов, латиница, цифры и _"
        if (friends.any { it.name.equals(name, ignoreCase = true) }) return "Этот друг уже в списке"
        friends.add(Friend("f" + System.currentTimeMillis(), name, false))
        persist()
        return null
    }

    fun removeFriend(f: Friend) {
        friends.remove(f)
        chats.remove(f.id)
        if (chatWith == f.id) chatWith = friends.firstOrNull()?.id ?: ""
        persist()
    }

    fun sendMessage(friendId: String, text: String) {
        chats[friendId] = chats[friendId].orEmpty() + ChatMsg(true, text, System.currentTimeMillis())
        persist()
    }

    // =====================================================
    //  Сброс
    // =====================================================
    fun resetAll() {
        sp.edit().clear().apply()
        clearDownloads()
        manifestCache.delete()
        loggedIn = false; nickname = ""; uuid = ""
        coins = 100; gems = 5
        ownedIds = Catalog.freeIds()
        skinId = "s_shadow"; capeId = ""; wingsId = "w_raven"; accId = ""
        lastDaily = ""; launches = 0
        ramMb = 2048; jvmArgs = "-XX:+UseG1GC"; showSnapshots = false; showOld = false
        selectedVersionId = ""
        friends.clear(); chats.clear(); seedDemo()
        loadVersions()
    }
}
